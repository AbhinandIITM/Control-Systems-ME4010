clc; clear ;
%%

m1=3; m2=5; c1=2; c2=5; k1=4; k2=12;
u = 0;
A = [0 1 0 0; %[output:group:581bf310] %[output:300cdcf1]
    -(k1+k2)/m1 -(c1+c2)/m1 k2/m1 c2/m1; %[output:300cdcf1]
    0 0 0 1; %[output:300cdcf1]
    k2/m2 c2/m2 -k2/m2 -c2/m2] %[output:group:581bf310] %[output:300cdcf1]
B = [0; 0; 0; 1/m2] %[output:3056fb43]
C = [1 0 0 0] %[output:4a4b1ba4]
%%
A_aa = [0] %[output:8cf2ee61]
A_ab = [1 0 0] %[output:390bc85d]
A_ba = [-(k2+k1)/m1 0 k2/m2]' %[output:99c1fa59]
A_bb = [-(c1+c2)/m1 k2/m1 c2/m1; %[output:group:2044edfc] %[output:35f63723]
     0 0 1; %[output:35f63723]
     c2/m2 -k2/m2 -c2/m2] %[output:group:2044edfc] %[output:35f63723]

B_a = [0] %[output:88239c93]
B_b = [0; 0; 1/m2] %[output:18712221]

C_a = [1] %[output:5da92bdc]
C_b = [0 0 0] %[output:91d39632]
%%
rank(obsv(A_bb,A_ab)) %[output:9074228c]
%%
eig(A) %[output:14a70ee5]
%%
p_o = [-5.9 -5.8 -1];

% Observer gain
Ke = place(A_bb', A_ab', p_o)';
%%
A_hat = A_bb - Ke*A_ab %[output:8b137a53]
B_hat = A_hat*Ke + A_ba - Ke*A_aa %[output:86285130]
F_hat = B_b - Ke*B_a %[output:1cc71afb]
C_hat = [zeros(1, 3);   %[output:group:796ab025] %[output:2ee8a3b1]
         eye(3)] %[output:group:796ab025] %[output:2ee8a3b1]
D_hat = [1;             %[output:group:3a711b4b] %[output:45eda3a2]
         Ke] %[output:group:3a711b4b] %[output:45eda3a2]
%%
t_sim = 0:0.01:10; % simulation time vector
x0 = [1; 0; -1; 0]; % Initial state: m1 pulled, m2 pushed
[t, x_true] = ode45(@(t, x) smd(x, A, B, u), t_sim, x0);

% Get the "true" measurement
y_true = (C * x_true')'; % y_true is just x_true(:,1)
%%
SNR = 30; % 30 dB signal-to-noise ratio (a reasonable noise level)
y_noise = awgn(y_true, SNR, 'measured');

%% ---------------------- Observer Simulation ----------------------
% The observer state is 'z', which is 3x1.
% We'll give it a "bad" initial guess of [0; 0; 0].

%%

z0 = [2; 1.5; 1];
%%
[t_o, z] = ode45(@(t_o, z) moo_dyn(t_o, z, A_hat, B_hat, F_hat, u, y_true, t), t_sim, z0);

% Noisy observer
[t_o_noise, z_noise] = ode45(@(t_o, z) moo_dyn(t_o, z, A_hat, B_hat, F_hat, u, y_noise, t), t_sim, z0);

%% ------------------- Full State Reconstruction -------------------
% Reconstruct the full state X_hat = C_hat*z + D_hat*y
% We must do this after the simulation.

% Reconstruct from noise-free data
% (C_hat * z')' gives a (N x 4) matrix
% (D_hat * y_true')' gives a (N x 4) matrix
x_hat = (C_hat * z')' + (D_hat * y_true')';

% Reconstruct from noisy data
x_hat_noise = (C_hat * z_noise')' + (D_hat * y_noise')';
%%
%% ---------------------- Plotting (Figure 1: Mass 1) ----------------------
figure('Name', 'Observer: Mass 1 States (x1, x2)', 'NumberTitle', 'off'); %[output:23b450a7]

% --- State 1: Mass 1 Displacement ---
subplot(2,2,1); %[output:23b450a7]
plot(t, x_true(:,1), 'k', 'LineWidth', 1.2); hold on; %[output:23b450a7]
plot(t_o, x_hat(:,1), 'b', 'LineWidth', 1.2); %[output:23b450a7]
plot(t_o_noise, x_hat_noise(:,1), 'r--', 'LineWidth', 1.2); %[output:23b450a7]
legend('True (x1)', 'Estimated (no noise)', 'Estimated (with noise)'); %[output:23b450a7]
xlabel('Time (s)'); %[output:23b450a7]
ylabel('Displacement (m)'); %[output:23b450a7]
title('Mass 1 Displacement (Measured)'); %[output:23b450a7]
grid on; %[output:23b450a7]

% --- State 2: Mass 1 Velocity ---
subplot(2,2,2); %[output:23b450a7]
plot(t, x_true(:,2), 'k', 'LineWidth', 1.2); hold on; %[output:23b450a7]
plot(t_o, x_hat(:,2), 'b', 'LineWidth', 1.2); %[output:23b450a7]
plot(t_o_noise, x_hat_noise(:,2), 'r--', 'LineWidth', 1.2); %[output:23b450a7]
legend('True (x2)', 'Estimated (no noise)', 'Estimated (with noise)'); %[output:23b450a7]
xlabel('Time (s)'); %[output:23b450a7]
ylabel('Velocity (m/s)'); %[output:23b450a7]
title('Mass 1 Velocity (Estimated)'); %[output:23b450a7]
grid on; %[output:23b450a7]

% --- Error in State 1 ---
subplot(2,2,3); %[output:23b450a7]
plot(t, x_true(:,1)-x_hat(:,1), 'b', 'LineWidth', 1.2); hold on; %[output:23b450a7]
plot(t, x_true(:,1)-x_hat_noise(:,1), 'r--', 'LineWidth', 1.2); %[output:23b450a7]
legend('Error (no noise)', 'Error (with noise)'); %[output:23b450a7]
xlabel('Time (s)'); %[output:23b450a7]
ylabel('Displacement Error (m)'); %[output:23b450a7]
title('x1 Estimation Error'); %[output:23b450a7]
grid on; %[output:23b450a7]

% --- Error in State 2 ---
subplot(2,2,4); %[output:23b450a7]
plot(t, x_true(:,2)-x_hat(:,2), 'b', 'LineWidth', 1.2); hold on; %[output:23b450a7]
plot(t, x_true(:,2)-x_hat_noise(:,2), 'r--', 'LineWidth', 1.2); %[output:23b450a7]
legend('Error (no noise)', 'Error (with noise)'); %[output:23b450a7]
xlabel('Time (s)'); %[output:23b450a7]
ylabel('Velocity Error (m/s)'); %[output:23b450a7]
title('x2 Estimation Error'); %[output:23b450a7]
grid on; %[output:23b450a7]

sgtitle('Observer Performance for Mass 1'); %[output:23b450a7]

%% ---------------------- Plotting (Figure 2: Mass 2) ----------------------
figure('Name', 'Observer: Mass 2 States (x3, x4)', 'NumberTitle', 'off'); %[output:6d755ab1]

% --- State 3: Mass 2 Displacement ---
subplot(2,2,1); %[output:6d755ab1]
plot(t, x_true(:,3), 'k', 'LineWidth', 1.2); hold on; %[output:6d755ab1]
plot(t_o, x_hat(:,3), 'b', 'LineWidth', 1.2); %[output:6d755ab1]
plot(t_o_noise, x_hat_noise(:,3), 'r--', 'LineWidth', 1.2); %[output:6d755ab1]
legend('True (x3)', 'Estimated (no noise)', 'Estimated (with noise)'); %[output:6d755ab1]
xlabel('Time (s)'); %[output:6d755ab1]
ylabel('Displacement (m)'); %[output:6d755ab1]
title('Mass 2 Displacement (Estimated)'); %[output:6d755ab1]
grid on; %[output:6d755ab1]

% --- State 4: Mass 2 Velocity ---
subplot(2,2,2); %[output:6d755ab1]
plot(t, x_true(:,4), 'k', 'LineWidth', 1.2); hold on; %[output:6d755ab1]
plot(t_o, x_hat(:,4), 'b', 'LineWidth', 1.2); %[output:6d755ab1]
plot(t_o_noise, x_hat_noise(:,4), 'r--', 'LineWidth', 1.2); %[output:6d755ab1]
legend('True (x4)', 'Estimated (no noise)', 'Estimated (with noise)'); %[output:6d755ab1]
xlabel('Time (s)'); %[output:6d755ab1]
ylabel('Velocity (m/s)'); %[output:6d755ab1]
title('Mass 2 Velocity (Estimated)'); %[output:6d755ab1]
grid on; %[output:6d755ab1]

% --- Error in State 3 ---
subplot(2,2,3); %[output:6d755ab1]
plot(t, x_true(:,3)-x_hat(:,3), 'b', 'LineWidth', 1.2); hold on; %[output:6d755ab1]
plot(t, x_true(:,3)-x_hat_noise(:,3), 'r--', 'LineWidth', 1.2); %[output:6d755ab1]
legend('Error (no noise)', 'Error (with noise)'); %[output:6d755ab1]
xlabel('Time (s)'); %[output:6d755ab1]
ylabel('Displacement Error (m)'); %[output:6d755ab1]
title('x3 Estimation Error'); %[output:6d755ab1]
grid on; %[output:6d755ab1]

% --- Error in State 4 ---
subplot(2,2,4); %[output:6d755ab1]
plot(t, x_true(:,4)-x_hat(:,4), 'b', 'LineWidth', 1.2); hold on; %[output:6d755ab1]
plot(t, x_true(:,4)-x_hat_noise(:,4), 'r--', 'LineWidth', 1.2); %[output:6d755ab1]
legend('Error (no noise)', 'Error (with noise)'); %[output:6d755ab1]
xlabel('Time (s)'); %[output:6d755ab1]
ylabel('Velocity Error (m/s)'); %[output:6d755ab1]
title('x4 Estimation Error'); %[output:6d755ab1]
grid on; %[output:6d755ab1]

sgtitle('Observer Performance for Mass 2'); %[output:6d755ab1]
%%
function dx = smd(x, A, B, u)
    dx = A*x + B*u;
end

% --- Minimum-Order Observer dynamics ---
function dz = moo_dyn(t_o, z, A_hat, B_hat, F_hat, u, y_vec, t_vec)
    % Interpolate the measured output y at the current time t_o
    y_interp = interp1(t_vec, y_vec, t_o);
    
    % MOO dynamics: z_dot = A_hat*z + B_hat*y + F_hat*u
    dz = A_hat*z + B_hat*y_interp + F_hat*u;
end

%[appendix]{"version":"1.0"}
%---
%[metadata:view]
%   data: {"layout":"onright"}
%---
%[output:300cdcf1]
%   data: {"dataType":"matrix","outputData":{"columns":4,"name":"A","rows":4,"type":"double","value":[["0","1.0000","0","0"],["-250.0000","-2.0000","150.0000","1.0000"],["0","0","0","1.0000"],["100.0000","0.6667","-100.0000","-0.6667"]]}}
%---
%[output:3056fb43]
%   data: {"dataType":"matrix","outputData":{"columns":1,"name":"B","rows":4,"type":"double","value":[["0"],["0"],["0"],["0.6667"]]}}
%---
%[output:4a4b1ba4]
%   data: {"dataType":"matrix","outputData":{"columns":4,"name":"C","rows":1,"type":"double","value":[["1","0","0","0"]]}}
%---
%[output:8cf2ee61]
%   data: {"dataType":"textualVariable","outputData":{"name":"A_aa","value":"0"}}
%---
%[output:390bc85d]
%   data: {"dataType":"matrix","outputData":{"columns":3,"name":"A_ab","rows":1,"type":"double","value":[["1","0","0"]]}}
%---
%[output:99c1fa59]
%   data: {"dataType":"matrix","outputData":{"columns":1,"name":"A_ba","rows":3,"type":"double","value":[["-250"],["0"],["100"]]}}
%---
%[output:35f63723]
%   data: {"dataType":"matrix","outputData":{"columns":3,"name":"A_bb","rows":3,"type":"double","value":[["-2.0000","150.0000","1.0000"],["0","0","1.0000"],["0.6667","-100.0000","-0.6667"]]}}
%---
%[output:88239c93]
%   data: {"dataType":"textualVariable","outputData":{"name":"B_a","value":"0"}}
%---
%[output:18712221]
%   data: {"dataType":"matrix","outputData":{"columns":1,"name":"B_b","rows":3,"type":"double","value":[["0"],["0"],["0.6667"]]}}
%---
%[output:5da92bdc]
%   data: {"dataType":"textualVariable","outputData":{"name":"C_a","value":"1"}}
%---
%[output:91d39632]
%   data: {"dataType":"matrix","outputData":{"columns":3,"name":"C_b","rows":1,"type":"double","value":[["0","0","0"]]}}
%---
%[output:9074228c]
%   data: {"dataType":"textualVariable","outputData":{"name":"ans","value":"3"}}
%---
%[output:14a70ee5]
%   data: {"dataType":"matrix","outputData":{"columns":1,"name":"ans","rows":4,"type":"complex","value":[["-1.1889 +17.8095i"],["-1.1889 -17.8095i"],["-0.1444 + 5.6007i"],["-0.1444 - 5.6007i"]]}}
%---
%[output:8b137a53]
%   data: {"dataType":"matrix","outputData":{"columns":3,"name":"A_hat","rows":3,"type":"double","value":[["-12.0333","150.0000","1.0000"],["0.3621","0","1.0000"],["7.7941","-100.0000","-0.6667"]]}}
%---
%[output:86285130]
%   data: {"dataType":"matrix","outputData":{"columns":1,"name":"B_hat","rows":3,"type":"double","value":[["-432.1700"],["-3.4948"],["219.1577"]]}}
%---
%[output:1cc71afb]
%   data: {"dataType":"matrix","outputData":{"columns":1,"name":"F_hat","rows":3,"type":"double","value":[["0"],["0"],["0.6667"]]}}
%---
%[output:2ee8a3b1]
%   data: {"dataType":"matrix","outputData":{"columns":3,"name":"C_hat","rows":4,"type":"double","value":[["0","0","0"],["1","0","0"],["0","1","0"],["0","0","1"]]}}
%---
%[output:45eda3a2]
%   data: {"dataType":"matrix","outputData":{"columns":1,"name":"D_hat","rows":4,"type":"double","value":[["1.0000"],["10.0333"],["-0.3621"],["-7.1274"]]}}
%---
%[output:23b450a7]
%   data: {"dataType":"image","outputData":{"height":286,"width":476}}
%---
%[output:6d755ab1]
%   data: {"dataType":"image","outputData":{"height":286,"width":476}}
%---
